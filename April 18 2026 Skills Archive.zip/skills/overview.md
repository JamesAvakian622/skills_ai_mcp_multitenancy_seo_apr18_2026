# **Antigravity Skills: Repository Overview**

## **Project Structure**

```text
.
├── README.md               # Authoritative entry point & engineering standards
├── mcp-tools.md            # The index of MCP tool-use capabilities
├── overview.md             # This structural reference (Auto-generated)
├── skills/                 # Unified repository for Standards & Functions
│   ├── ai-dev.md            # Documentation Skill
│   ├── ai-ecosystem.md      # Documentation Skill
│   ├── automated-testing.md # Documentation Skill
│   ├── best-practices.md    # Documentation Skill
│   ├── claude-workflows.md  # Documentation Skill
│   ├── clerk-auth.md        # Documentation Skill
│   ├── convex.md            # Documentation Skill
│   ├── github_actions.md    # Documentation Skill
│   ├── maintenance.md       # Documentation Skill
│   ├── mobile-skills.md     # Documentation Skill
│   ├── mongo-backend.md     # Documentation Skill
│   ├── multi-tenancy.md     # Documentation Skill
│   ├── nextjs.md            # Documentation Skill
│   ├── soc-reporting.md     # Documentation Skill
│   ├── stack-overview.md    # Documentation Skill
│   ├── tailwindcss.md       # Documentation Skill
│   ├── ux-ui.md             # Documentation Skill
│   ├── vercel.md            # Documentation Skill
│   ├── api-caller/      # Functional Tool implementation
│   ├── db-connector/    # Functional Tool implementation
│   ├── file-manager/    # Functional Tool implementation
└── docs/                   # System Blueprints & Core Architecture
```

## **Compliance & Validation Report**

### **ai-ecosystem.md**
- ⚠️ MISSING: Multi-Tenancy Enforcement (Clerk/Convex logic).
### **best-practices.md**
- ⚠️ MISSING: Multi-Tenancy Enforcement (Clerk/Convex logic).
### **mongo-backend.md**
- ⚠️ MISSING: SEO Optimization (JSON-LD/Meta Tags) documentation/standard.
### **multi-tenancy.md**
- ⚠️ MISSING: SEO Optimization (JSON-LD/Meta Tags) documentation/standard.
- ⚠️ MISSING: ISO 8601 Data Standard reference.
### **nextjs.md**
- ⚠️ MISSING: Multi-Tenancy Enforcement (Clerk/Convex logic).
### **soc-reporting.md**
- ⚠️ MISSING: ISO 8601 Data Standard reference.
### **tailwindcss.md**
- ⚠️ MISSING: SEO Optimization (JSON-LD/Meta Tags) documentation/standard.
- ⚠️ MISSING: Multi-Tenancy Enforcement (Clerk/Convex logic).

---
*Last Refresh: 2026-04-18T20:27:51.815089Z | Optical Automation Enforcement Agent*
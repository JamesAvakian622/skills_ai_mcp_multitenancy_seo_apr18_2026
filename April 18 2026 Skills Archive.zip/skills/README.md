# Antigravity AI Skill Set: Authoritative Edition
**Engineering Lead: James L. Avakian** | **Optical Automation, LLC**

A definitive, high-fidelity repository showcasing an elite full-stack architecture optimized for **AI Intelligence**, **Deep Multi-Tenancy**, and **SEO Excellence**. This skill set represents the state-of-the-art in modern web engineering, leveraging the latest stable releases of Next.js 15, Claude 3.5, and Vercel Edge infrastructure.

## 📁 Repository Structure

### [Core Skills](./skills/)
Detailed technical deep-dives into each layer of the Antigravity stack:
- [**Next.js 15**](./skills/nextjs.md): App Router, PPR, and Edge-first rendering.
- [**AI Development**](./skills/ai-dev.md): Claude 3.5 Sonnet, Tool Use, and Prompt Engineering.
- [**Clerk Authentication**](./skills/clerk-auth.md): Enterprise B2B multi-tenancy (OAuth, MFA, SSO).
- [**MongoDB Backend**](./skills/mongo-backend.md): Mongoose-powered transaction layers with strict tenant isolation.
- [**Vercel & Edge**](./skills/vercel.md): Global compute, WAF security, and performance analytics.
- [**Quality & DevOps**](./skills/automated-testing.md): Playwright, Vitest, and GitHub Actions CI/CD.

### [MCP Functional Tools](./mcp-tools.md)
The agentic intelligence layer enabling autonomous technical execution:
- [**MCP Configuration**](./mcp-tools.md): Tool definitions and manifest standards.
- [**Functional Skills**](./skills/): Implementation folders for AI tool-use.

### [Engineering Docs](./docs/)
- [**System Architecture**](./docs/architecture.md): The "Blueprints" of a multi-tenant AI ecosystem.
- [**Prompts & Logic**](./docs/prompts.md): Master system templates and structured output enforcement.
- [**Design & UX**](./docs/design-system.md): Minimalist, high-contrast AI design patterns.

### [Projects & Portfolio](./projects/)
- [**Flow AI**](./projects/README.md): A flagship case study in automated AI orchestration.

---

## 🚀 The Core Stack (v3.0)

### 🧠 Intelligence Layer
- **Claude 3.5 Sonnet**: Primary reasoning engine with native tool use and strict compliance.
- **RAG Architecture**: Retrieval-augmented pipelines with re-ranking and semantic search.
- **JSON-LD**: Automated schema generation for unparalleled SEO visibility.

### 🌐 Scalable Infrastructure
- **Server-First (RSC)**: 90% server-rendered codebases for industry-leading Core Web Vitals.
- **Multi-Tenancy**: Organization-scoped data isolation, custom domains, and SOC2-ready security.
- **Edge Runtime**: Compute-at-the-edge for sub-100ms global latency.

### 💎 Engineering Standards
- **Optical Automation Methodology**: Precision-focused development, type-safe architectures, and automated quality gates.
- **Zero-Trust Security**: End-to-end identity verification at every API and edge boundary.

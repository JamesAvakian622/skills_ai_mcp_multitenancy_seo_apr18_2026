import os
import json
import re
from datetime import datetime

# Antigravity Skills Maintenance Agent v2.0
# Automatically syncs overview.md, mcp-tools.md, and ENFORCES SEO/Tenancy Standards.

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKILLS_DIR = os.path.join(ROOT_DIR, 'skills')
OVERVIEW_FILE = os.path.join(ROOT_DIR, 'overview.md')
MCP_TOOLS_FILE = os.path.join(ROOT_DIR, 'mcp-tools.md')

def get_skills():
    items = os.listdir(SKILLS_DIR)
    docs = sorted([i for i in items if os.path.isfile(os.path.join(SKILLS_DIR, i)) and i.endswith('.md')])
    tools = sorted([i for i in items if os.path.isdir(os.path.join(SKILLS_DIR, i)) and os.path.exists(os.path.join(SKILLS_DIR, i, 'manifest.json'))])
    return {"docs": docs, "tools": tools}

def validate_standards(file_path):
    """Enforces SEO, Multi-Tenancy (Clerk/Convex), and ISO 8601 rules."""
    with open(file_path, 'r', errors='ignore') as f:
        content = f.read()
    
    issues = []
    
    # 1. SEO Optimization Check (JSON-LD, Meta Tags)
    if not re.search(r'JSON-LD|Meta Tags|Schema\.org', content, re.I):
        issues.append("MISSING: SEO Optimization (JSON-LD/Meta Tags) documentation/standard.")
        
    # 2. Multi-Tenancy Audit (Clerk & Convex Enforcement)
    if not re.search(r'Clerk|Convex|organizationId|multi-tenant', content, re.I):
        issues.append("MISSING: Multi-Tenancy Enforcement (Clerk/Convex logic).")
        
    # 3. ISO 8601 Compliance
    if "ISO 8601" not in content:
        issues.append("MISSING: ISO 8601 Data Standard reference.")
        
    return issues

def update_overview(skills):
    print('Syncing overview.md and validating standards...')
    tree_lines = [
        '# **Antigravity Skills: Repository Overview**',
        '',
        '## **Project Structure**',
        '',
        '```text',
        '.',
        '├── README.md               # Authoritative entry point & engineering standards',
        '├── mcp-tools.md            # The index of MCP tool-use capabilities',
        '├── overview.md             # This structural reference (Auto-generated)',
        '├── skills/                 # Unified repository for Standards & Functions',
    ]
    
    validation_report = []
    
    for d in skills['docs']:
        tree_lines.append(f"│   ├── {d.ljust(20)} # Documentation Skill")
        issues = validate_standards(os.path.join(SKILLS_DIR, d))
        if issues:
            validation_report.append(f"### **{d}**")
            validation_report.extend([f"- ⚠️ {msg}" for msg in issues])
    
    for t in skills['tools']:
        tree_lines.append(f"│   ├── {t}/".ljust(24) + " # Functional Tool implementation")
        
    tree_lines.extend([
        '└── docs/                   # System Blueprints & Core Architecture',
        '```',
        '',
        '## **Compliance & Validation Report**',
        ''
    ])
    
    if validation_report:
        tree_lines.extend(validation_report)
    else:
        tree_lines.append("✅ ALL FILES COMPLIANT with SEO, Multi-Tenancy, and ISO 8601 standards.")
        
    tree_lines.extend([
        '',
        '---',
        f'*Last Refresh: {datetime.utcnow().isoformat()}Z | Optical Automation Enforcement Agent*'
    ])
    
    with open(OVERVIEW_FILE, 'w') as f:
        f.write('\n'.join(tree_lines))

def update_mcp_tools(skills):
    print('Syncing mcp-tools.md...')
    if not os.path.exists(MCP_TOOLS_FILE):
        return

    with open(MCP_TOOLS_FILE, 'r') as f:
        content = f.read()
    
    section_start = '## **Active Functional Tools**'
    section_end = '---'
    
    start_idx = content.find(section_start)
    if start_idx == -1:
        return
        
    end_idx = content.find(section_end, start_idx + len(section_start))
    
    if start_idx != -1 and end_idx != -1:
        tools_list = []
        for i, t in enumerate(skills['tools']):
            manifest_path = os.path.join(SKILLS_DIR, t, 'manifest.json')
            try:
                with open(manifest_path, 'r') as f:
                    manifest = json.load(f)
                
                f_list = ", ".join([f"`{name}`" for name in manifest.get('functions', {}).keys()])
                tools_list.append(f"### **{i + 1}. {manifest.get('name', t)}**")
                tools_list.append(f"- **Folder:** `skills/{t}/`")
                tools_list.append(f"- **Purpose:** {manifest.get('description', 'No description.')}")
                tools_list.append(f"- **Functions:** {f_list}")
                tools_list.append("")
            except Exception as e:
                print(f"Error parsing manifest for {t}: {e}")

        new_section = "\n\n" + "\n".join(tools_list) + "\n"
        final_content = content[:start_idx + len(section_start)] + new_section + content[end_idx:]
        
        with open(MCP_TOOLS_FILE, 'w') as f:
            f.write(final_content)

if __name__ == "__main__":
    try:
        skills = get_skills()
        update_overview(skills)
        update_mcp_tools(skills)
        print('✅ Maintenance Refresh Complete with Standards Enforcement.')
    except Exception as e:
        print(f'❌ Maintenance Failed: {e}')
        exit(1)

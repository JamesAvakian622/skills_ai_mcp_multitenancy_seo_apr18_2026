const fs = require('fs');
const path = require('path');

/**
 * Antigravity Skills Maintenance Agent
 * Automatically syncs overview.md and mcp-tools.md with the actual filesystem state.
 */

const ROOT_DIR = path.resolve(__dirname, '..');
const SKILLS_DIR = path.join(ROOT_DIR, 'skills');
const OVERVIEW_FILE = path.join(ROOT_DIR, 'overview.md');
const MCP_TOOLS_FILE = path.join(ROOT_DIR, 'mcp-tools.md');

function getSkills() {
    const items = fs.readdirSync(SKILLS_DIR, { withFileTypes: true });
    const docs = items.filter(item => item.isFile() && item.name.endsWith('.md')).map(i => i.name);
    const tools = items.filter(item => item.isDirectory() && fs.existsSync(path.join(SKILLS_DIR, item.name, 'manifest.json'))).map(i => i.name);
    return { docs, tools };
}

function updateOverview({ docs, tools }) {
    console.log('Syncing overview.md...');
    const tree = [
        '# **Antigravity Skills: Repository Overview**',
        '',
        '## **Project Structure**',
        '',
        '```text',
        '.',
        '├── README.md               # Authoritative entry point & engineering standards',
        '├── mcp-tools.md            # The index of MCP tool-use capabilities',
        '├── overview.md             # This structural reference (Auto-generated)',
        '├── skills/                 # Unified repository for Standards & Functions',
        ...docs.map(d => `│   ├── ${d.padEnd(20)} # Documentation Skill`),
        ...tools.map(t => `│   ├── ${t}/`.padEnd(20) + ' # Functional Tool implementation'),
        '└── docs/                   # System Blueprints & Core Architecture',
        '```',
        '',
        '---',
        `*Last Refresh: ${new Date().toISOString()} | Optical Automation, LLC*`
    ].join('\n');
    
    fs.writeFileSync(OVERVIEW_FILE, tree);
}

function updateMCPTools({ tools }) {
    console.log('Syncing mcp-tools.md...');
    let content = fs.readFileSync(MCP_TOOLS_FILE, 'utf8');
    
    // Construct the Active Functional Tools section
    const sectionStart = '## **Active Functional Tools**';
    const sectionEnd = '---';
    const startIndex = content.indexOf(sectionStart);
    const endIndex = content.indexOf(sectionEnd, startIndex + sectionStart.length);
    
    if (startIndex !== -1 && endIndex !== -1) {
        const toolsList = tools.map((t, i) => {
            const manifestPath = path.join(SKILLS_DIR, t, 'manifest.json');
            const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
            return [
                `### **${i + 1}. ${manifest.name}**`,
                `- **Folder:** \`skills/${t}/\``,
                `- **Purpose:** ${manifest.description}`,
                `- **Functions:** ${Object.keys(manifest.functions).map(f => `\`${f}\``).join(', ')}.`,
                ''
            ].join('\n');
        }).join('\n');
        
        const newSection = `\n\n${toolsList}\n`;
        content = content.slice(0, startIndex + sectionStart.length) + newSection + content.slice(endIndex);
        fs.writeFileSync(MCP_TOOLS_FILE, content);
    }
}

function main() {
    try {
        const skills = getSkills();
        updateOverview(skills);
        updateMCPTools(skills);
        console.log('✅ Maintenance Refresh Complete.');
    } catch (error) {
        console.error('❌ Maintenance Failed:', error.message);
        process.exit(1);
    }
}

main();

# **Convex: Real-Time Multi-Tenant Backend**
**Direct Database Logic for Optical Automation, LLC**

## **1. Multi-Tenant Architecture**
- **Clerk Integration**: Native handshake with Clerk using `auth.getUser()`. Every query and mutation must verify the `organizationId` from the Clerk JWT.
- **Tenancy Scoping**: Using Convex's internal authorization logic to automatically filter results by `orgId`, ensuring zero "leakage" between tenants.
- **Real-Time Subscription**: Leveraging Convex's reactive nature to push data updates (AI generation status, log entries) to the Next.js 15 frontend in sub-10ms.

## **2. Type-Safe AI Orchestration**
- **Server Functions**: Using `mutation` and `query` as strict API boundaries with full TypeScript safety.
- **Vector Search**: Integrating Convex's built-in vector search for RAG pipelines, indexed by `orgId` for multi-tenant isolation.
- **ISO 8601 & SEO**: All timestamps are persisted in **ISO 8601**. Search-relevant data is stored formatted for **JSON-LD** injection.

## **3. SOC2 & Security Enforcement**
- **Action Layers**: Using Convex `actions` for high-latency tasks (like calling the Claude 3.5 Sonnet API) to keep the database transactions ACID-compliant.
- **Audit Logging**: Every mutation triggers a background audit log entry with **Meta Tags** for tracking and compliance.
- **Zero-Trust**: The backend assumes no client-side trust, validating every input with `v.string()`, `v.object()`, etc.

---
*Verified for Convex v1.0+ | SEO Optimization & Multi-Tenancy Enforced.*

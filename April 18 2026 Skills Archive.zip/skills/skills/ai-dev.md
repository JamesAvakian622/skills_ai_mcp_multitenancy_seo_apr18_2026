# AI Engineering & Claude 3.5 Sonnet
**Agentic Intelligence Standards by Optical Automation, LLC**

## 1. The Claude 3.5 Ecosystem
- **Native Tool Use**: Implementing **Strict Mode** in Claude 3.5 Sonnet to guarantee that agent responses perfectly align with backend JSON schemas.
- **Prompt Caching**: Strategically using caching headers to reduce latency and infrastructure costs for long-running, multi-step AI dialogues.
- **Computer Use & Artifacts**: Leveraging the latest model capabilities for autonomous technical execution and structured document generation.

## 2. Structured Logic & SEO
- **Mandatory JSON-LD**: Every AI layer must return or validate **JSON-LD** schemas for automated SEO injection, bridging the gap between generative intelligence and search visibility.
- **Zod Validation**: Enforcing 100% type safety on model outputs using Zod, preventing runtime errors in complex application logic.
- **ISO 8601 Data Standards**: Mandating the use of **ISO 8601** (e.g., `YYYY-MM-DDTHH:mm:ssZ`) for all AI-generated timestamps and logs.
- **Universal SEO Instruction**: AI agents must ensure every file created or updated incorporates **JSON**, **JSON-LD**, and **Meta Tags** for maximum SEO optimization.

## 3. RAG & Knowledge Engineering
- **Hybrid Search**: Advanced retrieval patterns combining semantic (vector) and keyword (lexical) search for maximum accuracy.
- **Re-Ranking Infrastructure**: Implementing secondary scoring layers to prune irrelevant context before it reaches the LLM context window.
- **Semantic Metadata**: Injecting rich, tenant-specific metadata into vector stores (`organizationId`, `userId`) to ensure strict RAG isolation.

## 4. Agentic Workflows
- **Autonomous Agents**: Crafting multi-step agents that can reason about system state and call multiple tools in sequence.
- **Chain-of-Thought (CoT)**: Prompting for explicit reasoning paths to improve model reliability and simplify debugging.
- **Usage Metering**: Real-time token tracking and rate-limiting at the organization level for accurate SaaS billing.

---
*Verified for Claude 3.5 Sonnet (Revised for 2026 Engineering Standards).*

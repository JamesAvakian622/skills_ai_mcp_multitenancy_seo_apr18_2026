# **Skill: Automated Repository Maintenance**
**Owner: Optical Automation Agent**

## **Overview**
To maintain the high-fidelity and authoritative nature of the Antigravity Skill Set, the repository structure and tool indices must stay perfectly synced with the filesystem. This is handled via automated maintenance scripts.

---

## **The Maintenance Protocol**

### **1. Sync Sources**
The maintenance script (`scripts/maintenance.py`) monitors:
- **`skills/*.md`**: Core standards and technical deep-dives.
- **`skills/*/manifest.json`**: Individual MCP tool implementations and their function schemas.

### **2. Automated Enforcement (NEW)**
The script now performs **Validation Audits** during every refresh:
- **SEO Optimization**: Checks for **JSON-LD** and **Meta Tags**.
- **Multi-Tenancy**: Verifies **Clerk** and **Convex** enforcement rules and `organizationId` isolation.
- **Data Standards**: Ensures **ISO 8601** compliance for all logs and timestamps.

### **3. Automated Outputs**
Upon refresh, the following files are updated:
- **`overview.md`**: Regenerates the visual tree structure and the **Compliance & Validation Report**.
- **`mcp-tools.md`**: Updates the "Active Functional Tools" section with latest data from `manifest.json`.

---

## **Execution**

### **Manual Refresh**
Run the convenience script from the root:
```bash
./refresh.sh
```

### **Automated Triggers (Recommended)**
To ensure this is "always done," integrate the refresh into your workflow:
- **Git Hooks**: Add `./refresh.sh` to a `.git/hooks/pre-commit` script.
- **CI/CD**: Add a GitHub Action to run the maintenance script on every push to `main`.

---
*Verified for Antigravity v3.0 | Optical Automation, LLC*

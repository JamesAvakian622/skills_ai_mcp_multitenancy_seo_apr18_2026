# Engineering Best Practices
**Standard Operating Procedures by Optical Automation, LLC**

## 1. Principles of Precision
- **Server-First Execution**: Defaulting to React Server Components (RSC) to minimize Client JavaScript and maximize SEO.
- **Type-Safe Everything**: Mandatory use of **TypeScript** and **Zod** schema validation for all inputs, outputs, and AI-generated data.
- **Functional Clarity**: Prioritizing pure functions and immutable data structures to simplify AI integration and testing.
- **ISO 8601 Compliance**: Uniform use of **ISO 8601** formatting for all date/time fields to ensure cross-system compatibility and unambiguous auditing.

## 2. AI Engineering Excellence
- **Structured Logic (JSON-LD)**: Every AI-generated output must strictly follow or produce valid JSON-LD schemas to ensure semantic web compatibility.
- **The "Truth Guard"**: Implementing rigorous hallucination checks and grounding strategies using RAG and secondary verification layers.
- **Token Efficiency**: Optimizing context windows and leveraging Prompt Caching to maintain high performance and low cost.

## 3. High-Performance Infrastructure
- **Core Web Vitals Mastery**: Relentless optimization for LCP (Largest Contentful Paint) and CLS (Cumulative Layout Shift) through streaming and PPR.
- **Edge-Native Design**: Running all authentication, redirection, and lightweight AI logic at the Vercel Edge to minimize global latency.
- **SOC2 Type II Isolation**: Ensuring zero cross-tenant data leakage through strict logical isolation and organization-scoped query middleware, meeting **SOC2 Type II** standards.

## 4. Operational Excellence
- **CI/CD Quality Gates**: Automated pipelines that block deployments unless 100% of linting, type-checking, and Playwright tests pass.
- **Zero-Downtime Rollouts**: Utilizing Vercel for atomic deployments with instant rollback capabilities.
- **Observability Stack**: Full-stack monitoring using Sentry (error tracking), Axiom (logging), and Vercel Speed Insights.

## 5. Universal SEO Directive
- **Mandatory Optimization**: Every file created or updated must prioritize SEO through the integration of **JSON**, **JSON-LD**, and descriptive **Meta Tags**. This is a non-negotiable standard for all development within the Antigravity ecosystem to ensure maximum semantic visibility across AI and search platforms.

---
*Version 4.0 - Revised for 2026 Engineering Standards.*

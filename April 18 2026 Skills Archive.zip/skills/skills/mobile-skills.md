# Mobile Development: SwiftUI & Android SDK
**Authoritative Standards for Optical Automation, LLC**

## 1. SwiftUI & Apple Ecosystem (iOS/iPadOS)
- **Declarative State Management**: Utilizing the modern `Observation` framework (iOS 17+) for granular, high-performance state tracking, moving beyond legacy `ObservableObject` patterns.
- **Swift Concurrency (Structured)**: Architecting thread-safe applications using `async/await`, `Actors`, and `GlobalActors` to ensure seamless UI responsiveness during heavy background AI processing.
- **SwiftData Integration**: Implementing robust, schema-driven data persistence with SwiftData for efficient local caching and synchronization with cloud-based tenant record-sets.
- **High-Fidelity Animations**: Leveraging the `phaseAnimator` and `keyframeAnimator` APIs for rich, interactive transitions that define a premium mobile experience.
- **Core ML & On-Device AI**: Integrating specialized model execution via Core ML to process privacy-focused AI tasks directly on the Neural Engine.

## 2. Android SDK & Jetpack Compose
- **Modern UI Composition**: Building scalable, declarative interfaces with Jetpack Compose, emphasizing reusable components and Material Design 3 (M3) aesthetics.
- **Reactive Streams with Kotlin Flow**: Implementing `StateFlow` and `SharedFlow` within Lifecycle-aware ViewModels to handle real-time data synchronization and complex UI states.
- **Dagger-Hilt Dependency Injection**: Enforcing modular architecture and testability through Hilt, ensuring clean separation of concerns in enterprise-grade mobile deployments.
- **Room Persistence Library**: Architecting reliable offline-first capabilities using Room, with support for reactive queries and automated migrations.
- **WorkManager & Background Tasks**: Deferring intensive data syncs and AI pre-computation to WorkManager for battery-efficient, guaranteed execution.

## 3. High-Performance Mobile Patterns
- **Native-First Philosophy**: Forgoing hybrid abstractions in favor of native Swift/Kotlin to maximize performance, lower latency, and provide direct access to hardware-level optimizations.
- **Multi-Tenant Authentication**: Integrating Clerk or custom OAuth flows with platform-native Biometric (FaceID / Fingerprint) SDKs for secure, frictionless entry.
- **Networking & API Resiliency**: Implementing exponential backoff, circuit breakers, and unified JSON-LD serialization using `Retrofit` and `URLSession`.
- **ISO 8601 Consistent Logging**: Standardizing on **ISO 8601** (UTC) for all on-device logging, analytics events, and server synchronization payloads.
- **Accessibility (a11y)**: Prioritizing Dynamic Type, Screen Readers (VoiceOver/TalkBack), and high-contrast support to meet global enterprise accessibility standards.

---
*Verified for SwiftUI (iOS 17+) and Android SDK (API 34+) - 2026 Engineering Standards.*

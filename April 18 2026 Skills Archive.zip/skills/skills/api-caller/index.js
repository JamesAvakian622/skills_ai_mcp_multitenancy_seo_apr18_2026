/**
 * Antigravity: API Caller Functional Skill
 * Standards: ISO 8601, SOC2 Type II Logging
 */

const axios = require('axios');

async function callApi(method, url, data = null, headers = {}) {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] AUTH_EVENT: Initializing ${method} request to ${url}`);
    
    try {
        const response = await axios({
            method,
            url,
            data,
            headers: {
                ...headers,
                'X-Antigravity-Agent': 'v3.0',
                'X-Compliance-Level': 'SOC2'
            }
        });
        
        return {
            success: true,
            status: response.status,
            data: response.data,
            timestamp
        };
    } catch (error) {
        console.error(`[${timestamp}] COMPLIANCE_ERROR: API call failed`, error.message);
        return {
            success: false,
            error: error.message,
            timestamp
        };
    }
}

module.exports = { callApi };

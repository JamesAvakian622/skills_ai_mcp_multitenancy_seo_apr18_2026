#!/bin/bash
python3 scripts/maintenance.py

# **MCP Tools: Functional Intelligence Layer**

## **Overview**

This document describes all **MCP (Model Context Protocol)** tools integrated into the Antigravity ecosystem. These tools provide the "hands" for our AI agents, enabling them to interact with external APIs, local files, and secure databases while adhering to **SOC2 Type II** and **ISO 8601** standards.

Each tool lives inside the `skills/` directory as a modular unit.

---

## **Folder Structure**

To maintain a clean separation between **Standards (Markdown)** and **Functional Skills (Code)**, the `skills/` directory follows this hierarchy:

```text
skills/
  ├── documentation-skill.md (Core standard)
  ├── functional-tool/        (MCP Implementation)
  │     ├── manifest.json
  │     └── index.js / main.py
  └── ...
mcp-tools.md
```

Each functional tool must include a `manifest.json` defining its capabilities, security boundaries, and schema.

---

## **Active Functional Tools**

### **1. api-caller**
- **Folder:** `skills/api-caller/`
- **Purpose:** Antigravity Secure API Caller with SOC2 logging and ISO 8601 compliance.
- **Functions:** `get`, `post`

### **2. db-connector**
- **Folder:** `skills/db-connector/`
- **Purpose:** Antigravity Multi-Tenant MongoDB Connector with strict logic isolation.
- **Functions:** `query`

### **3. file-manager**
- **Folder:** `skills/file-manager/`
- **Purpose:** Antigravity Secure File Manager with SEO management and ISO 8601 compliance.
- **Functions:** `read`, `write`

---

## **Core Documentation Skills**

The tools above operate under the governance of our **Standard Skills**:

- [**AI Development Standards**](./skills/ai-dev.md)
- [**MongoDB Best Practices**](./skills/mongo-backend.md)
- [**SOC2 Compliance Protocols**](./skills/soc-reporting.md)

---

## **Example Manifest**

```json
{
  "name": "file-manager",
  "description": "Controlled read/write access to local files with SEO enforcement.",
  "version": "1.0.0",
  "functions": {
    "write_file": {
      "description": "Write a file with mandatory SEO metadata",
      "parameters": {
        "type": "object",
        "properties": {
          "path": { "type": "string" },
          "content": { "type": "string" },
          "seo_tags": { "type": "object" }
        },
        "required": ["path", "content"]
      }
    }
  }
}
```

---

## **Adding New Functional Skills**

1. Create a sub-folder within `skills/` (e.g., `skills/custom-tool/`).
2. Define the `manifest.json` with Zod-compatible schemas.
3. Implement the logic (Node.js/Python/TypeScript).
4. Register the tool in the **Antigravity AI Agent** system prompt.

---

## **Security & Standards**

- **Isolation**: Tools must operate within their assigned tenant context (`organizationId`).
- **Auditability**: Every tool call is logged with an **ISO 8601** timestamp.
- **Type Safety**: Manifests must use JSON Schema to ensure strict input validation.

---
*Verified for Antigravity v3.0 | Optical Automation, LLC*

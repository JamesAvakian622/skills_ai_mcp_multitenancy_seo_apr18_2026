# Master Prompt Engineering Guide
**Logic Standards by Optical Automation, LLC**

## 1. The Authoritative System Prompt
Every AI agent in the Antigravity ecosystem must be initialized with a rigid, role-defined system prompt that enforces architectural compliance.

### Core System Blueprint
```markdown
# Role: Antigravity Engineering Agent
# Context: You are operating within the James L. Avakian / Optical Automation stack.
# Constraints:
- Always prioritize Next.js 15 Server-First patterns.
- Every semantic output MUST be valid JSON-LD.
- STRICTLY follow provided tool schemas (no hallucinated parameters).
- Maintain 100% tenant isolation (never use ID-less queries).
```

## 2. Tool-Calling & Structured Logic
- **Strict Mode**: Utilizing Claude 3.5's `strict: true` parameter to guarantee schema adherence.
- **JSON-LD Enforcement**: Forcing models to wrap all semantic data in `<script type="application/ld+json">` for SEO-ready server-side rendering.

## 3. Advanced Context Patterns
- **Prompt Caching**: Designing reusable prompt "blocks" for common operations (Auth, RAG, Dashboard Gen) to minimize infrastructure overhead.
- **Multi-Step Reasoning (CoT)**: Instructing models to "Think Step-by-Step" inside hidden reasoning blocks before generating final structured outputs.

## 4. RAG Scoping
Prompts must include a dynamic "Context Sentinel" to prevent cross-tenant leakage:
> "You have access to data ONLY for Organization ID: [ORG_ID]. If the context provided does not match this ID, you must return an error and terminate."

---
*Proprietary prompt standards for secure AI orchestration.*

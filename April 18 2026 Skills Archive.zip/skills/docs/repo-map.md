# **Antigravity: Repository Map**

## **Core Maintenance & Logic**
- **[refresh.sh](./refresh.sh)**: **TRIGGER** - Syncs repository files and audits engineering standards.
- **[overview.md](./overview.md)**: **REPORT** - Visual tree structure and automated Compliance Audit results.
- **[mcp-tools.md](./mcp-tools.md)**: **INDEX** - Authoritative registry of functional MCP tool schemas.

## **Execution Layers**
- **[scripts/maintenance.py](./scripts/maintenance.py)**: **ENGINE** - Python-based validator for SEO, Multi-Tenancy, and ISO 8601 logic.
- **[skills/convex.md](./skills/convex.md)**: **NEW** - High-fidelity standard for Real-time Multi-tenant Database architecture.
- **[skills/maintenance.md](./skills/maintenance.md)**: **UPDATED** - Documentation of the Audit & Enforcement protocol.
- **skills/**: All other technical skill files being actively audited for standards compliance.

---
*Verified for Antigravity v3.0 | Optical Automation, LLC*
